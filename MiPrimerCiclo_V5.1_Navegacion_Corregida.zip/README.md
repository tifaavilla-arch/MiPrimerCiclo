# Mi Primer Ciclo — V5.0 Final

Proyecto Android de **Mi Primer Ciclo**, orientado a niñas y adolescentes que comienzan su ciclo menstrual.

## Contenido
- Inicio
- Calendario
- Aprendizaje
- Registro/bienestar (base visual V5.0)
- Kit menstrual
- Ayuda y privacidad
- Base preparada para Free/Premium
- Compilación automática del APK mediante GitHub Actions

## Cómo obtener el APK sin Android Studio en el teléfono

1. Sube este proyecto a un repositorio de GitHub.
2. En GitHub entra a **Actions**.
3. Selecciona **Compilar Mi Primer Ciclo APK**.
4. Pulsa **Run workflow**.
5. Cuando termine, abre la ejecución y descarga el artefacto **MiPrimerCiclo-V5.0-APK**.
6. Dentro estará `app-debug.apk`.

El proyecto incluye `.github/workflows/build-apk.yml`, que configura Java 17 y Gradle 8.10 automáticamente.

## Nota
La compilación es Debug y sirve para instalar y probar la aplicación. Para publicar en Google Play necesitaremos después una versión Release firmada con una clave de firma y completar la configuración de publicación.
