package com.miprimer.ciclo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Pink = Color(0xFFE98AB8)
private val Purple = Color(0xFF7254A5)
private val Mint = Color(0xFFB9E5D5)
private val Cream = Color(0xFFFFF7FB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    var screen by remember { mutableStateOf("home") }
    var selectedTab by remember { mutableIntStateOf(0) }

    fun navigate(destination: String) {
        screen = destination
        selectedTab = when (destination) {
            "home" -> 0
            "calendar" -> 1
            "learn" -> 2
            else -> 3
        }
    }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Cream) {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f)) {
                    when (screen) {
                        "home" -> Home(
                            onCalendar = { navigate("calendar") },
                            onLearn = { navigate("learn") },
                            onMood = { navigate("mood") },
                            onKit = { navigate("kit") },
                            onHelp = { navigate("help") }
                        )
                        "calendar" -> CalendarScreen(onBack = { navigate("home") })
                        "learn" -> LearnScreen(onBack = { navigate("home") })
                        "mood" -> MoodScreen(onBack = { navigate("home") })
                        "kit" -> KitScreen(onBack = { navigate("home") })
                        "help" -> HelpScreen(onBack = { navigate("home") })
                        "privacy" -> PrivacyScreen(onBack = { navigate("more") })
                        "more" -> MoreScreen(
                            onKit = { navigate("kit") }, onHelp = { navigate("help") },
                            onPrivacy = { navigate("privacy") }
                        )
                        else -> Home(
                            onCalendar = { navigate("calendar") }, onLearn = { navigate("learn") },
                            onMood = { navigate("mood") }, onKit = { navigate("kit") }, onHelp = { navigate("help") }
                        )
                    }
                }
                NavigationBar(containerColor = Color.White) {
                    val labels = listOf("Inicio", "Calendario", "Aprender", "Más")
                    val icons = listOf("⌂", "◫", "★", "⋯")
                    labels.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { navigate(listOf("home", "calendar", "learn", "more")[index]) },
                            icon = { Text(icons[index], fontSize = 20.sp) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String? = null, onBack: (() -> Unit)? = null) {
    Column(Modifier.padding(start = 22.dp, end = 22.dp, top = 16.dp, bottom = 10.dp)) {
        if (onBack != null) {
            TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) { Text("‹  Volver", color = Purple, fontSize = 16.sp) }
        }
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Purple)
        subtitle?.let { Text(it, fontSize = 15.sp, color = Color.DarkGray) }
    }
}

@Composable
fun CardButton(title: String, text: String, emoji: String, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 28.sp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, color = Purple)
                Text(text, fontSize = 13.sp)
            }
            Text("›", fontSize = 28.sp, color = Pink)
        }
    }
}

@Composable
fun Home(onCalendar: () -> Unit, onLearn: () -> Unit, onMood: () -> Unit, onKit: () -> Unit, onHelp: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Header("Mi Primer Ciclo", "Tu cuerpo • Tu ritmo • Tu bienestar")
            Text("Aprende, conoce y entiende los cambios de tu cuerpo. 💜", Modifier.padding(horizontal = 22.dp), fontSize = 17.sp)
            Spacer(Modifier.height(10.dp))
        }
        item { CardButton("Mi calendario", "Registra tus días de forma sencilla", "📅", onCalendar) }
        item { CardButton("Aprendiendo sobre mi cuerpo", "Información clara y apropiada para tu edad", "📚", onLearn) }
        item { CardButton("¿Cómo me siento hoy?", "Registra emociones y síntomas", "😊", onMood) }
        item { CardButton("Mi kit menstrual", "Qué llevar contigo para sentirte preparada", "🎒", onKit) }
        item { CardButton("Necesito ayuda", "Hablar con un adulto de confianza es importante", "💗", onHelp) }
        item {
            Card(Modifier.fillMaxWidth().padding(22.dp), RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFF1EAF9))) {
                Column(Modifier.padding(18.dp)) {
                    Text("Tu privacidad es nuestra prioridad 🔒", fontWeight = FontWeight.Bold, color = Purple)
                    Text("Tus datos se guardan localmente en el dispositivo.", Modifier.padding(top = 6.dp), fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun CalendarScreen(onBack: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        item { Header("Mi calendario", "Registra tus días con tranquilidad", onBack) }
        item {
            Card(Modifier.padding(16.dp).fillMaxWidth(), RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Calendario", fontWeight = FontWeight.Bold, color = Purple, fontSize = 20.sp)
                    Text("Marca los días de tu menstruación en tu calendario personal.", Modifier.padding(top = 8.dp))
                    Spacer(Modifier.height(14.dp))
                    Text("L    M    X    J    V    S    D", fontWeight = FontWeight.Bold)
                    (1..5).forEach { week ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            (1..7).forEach { day ->
                                val number = (week - 1) * 7 + day
                                Box(Modifier.padding(vertical = 5.dp).size(34.dp).background(if (number in 5..7) Color(0xFFF3A2C6) else Color.Transparent, RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
                                    Text(if (number <= 31) number.toString() else "")
                                }
                            }
                        }
                    }
                    Text("Puedes registrar tus fechas y observar cómo cambia tu ciclo. Al principio puede ser irregular.", Modifier.padding(top = 12.dp), color = Purple)
                }
            }
        }
    }
}

@Composable
fun LearnScreen(onBack: () -> Unit) {
    var article by remember { mutableStateOf<String?>(null) }
    val topics = listOf(
        "¿Qué es la pubertad?" to "La pubertad es una etapa natural en la que tu cuerpo y tus emociones cambian poco a poco. Cada persona la vive a su propio ritmo.",
        "Cambios en mi cuerpo" to "Puedes notar crecimiento, cambios en la piel, vello corporal y cambios en tus emociones. Son parte del desarrollo.",
        "Mi primera menstruación" to "La menstruación es el sangrado que ocurre cuando el cuerpo elimina el revestimiento del útero. No es algo sucio ni motivo de vergüenza.",
        "Higiene y cuidado" to "Cambia tus productos menstruales con regularidad, lávate las manos y usa ropa interior limpia. Elige lo que te resulte cómodo.",
        "Mitos y verdades" to "Menstruar es una función normal del cuerpo. Puedes bañarte, hacer actividad física si te sientes bien y pedir ayuda cuando tengas dudas."
    )
    if (article == null) {
        LazyColumn(Modifier.fillMaxSize()) {
            item { Header("Aprendiendo sobre mi cuerpo", "Información sencilla y sin vergüenza", onBack) }
            topics.forEach { (title, _) -> item { CardButton(title, "Toca para leer información", "🌷") { article = title } } }
        }
    } else {
        val content = topics.first { it.first == article }.second
        Column(Modifier.fillMaxSize().padding(22.dp)) {
            TextButton(onClick = { article = null }, contentPadding = PaddingValues(0.dp)) { Text("‹  Volver a los temas", color = Purple) }
            Text(article!!, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Purple)
            Text(content, Modifier.padding(top = 18.dp), fontSize = 17.sp, lineHeight = 25.sp)
            Text("Si tienes preguntas o algo te preocupa, conversa con una persona adulta de confianza.", Modifier.padding(top = 20.dp), color = Purple)
        }
    }
}

@Composable
fun MoodScreen(onBack: () -> Unit) {
    val feelings = listOf("😊 Feliz", "😌 Tranquila", "😴 Cansada", "😟 Preocupada", "😣 Con cólicos", "🥺 Sensible")
    val symptoms = listOf("Cólicos", "Dolor de cabeza", "Cansancio", "Acné", "Hinchazón", "Antojos")
    var feeling by remember { mutableStateOf("") }
    val selectedSymptoms = remember { mutableStateListOf<String>() }
    var saved by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        item { Header("¿Cómo me siento hoy?", "Puedes registrar cómo te sientes", onBack) }
        item { Text("Elige una emoción", color = Purple, fontWeight = FontWeight.Bold) }
        items(feelings.size) { index ->
            val option = feelings[index]
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = feeling == option, onClick = { feeling = option; saved = false })
                Text(option)
            }
        }
        item { Spacer(Modifier.height(8.dp)); Text("Síntomas (opcional)", color = Purple, fontWeight = FontWeight.Bold) }
        items(symptoms.size) { index ->
            val symptom = symptoms[index]
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = symptom in selectedSymptoms, onCheckedChange = { checked -> if (checked) selectedSymptoms.add(symptom) else selectedSymptoms.remove(symptom); saved = false })
                Text(symptom)
            }
        }
        item {
            Button(onClick = { saved = true }, modifier = Modifier.fillMaxWidth().padding(vertical = 18.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("Guardar registro") }
            if (saved) Text("Registro guardado en esta sesión. 💜", color = Purple)
        }
    }
}

@Composable
fun KitScreen(onBack: () -> Unit) {
    val things = listOf("Toalla higiénica", "Toallitas húmedas", "Ropa interior extra", "Bolsita para guardar", "Pañuelos", "Botellita de agua")
    val checked = remember { mutableStateListOf<String>() }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        item { Header("Mi kit menstrual", "Una pequeña preparación puede darte tranquilidad", onBack) }
        item { Text("Puedes marcar lo que ya guardaste:", color = Purple) }
        items(things.size) { index ->
            val thing = things[index]
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = thing in checked, onCheckedChange = { value -> if (value) checked.add(thing) else checked.remove(thing) })
                    Text(thing)
                }
            }
        }
        item { Text("Consejo: guarda tu kit en una bolsita limpia y cómoda. 💗", Modifier.padding(vertical = 18.dp), color = Purple) }
    }
}

@Composable
fun HelpScreen(onBack: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        item { Header("Necesito ayuda", "No tienes que resolver tus dudas sola", onBack) }
        item {
            Card(Modifier.fillMaxWidth().padding(vertical = 8.dp), RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Hablar es importante 💗", fontWeight = FontWeight.Bold, color = Purple, fontSize = 20.sp)
                    Text("Si tienes dudas, miedo o algo te preocupa, busca a una persona adulta en quien confíes: mamá, papá, un familiar, profesora u orientadora.", Modifier.padding(top = 10.dp), fontSize = 16.sp)
                }
            }
        }
        item { Text("Busca atención de salud si tienes dolor muy intenso, sangrado que empapa una toalla cada hora durante varias horas, mareos o te sientes muy mal.", Modifier.padding(vertical = 14.dp), color = Purple) }
    }
}


@Composable
fun MoreScreen(onKit: () -> Unit, onHelp: () -> Unit, onPrivacy: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        item { Header("Más", "Herramientas y acompañamiento") }
        item { CardButton("Mi kit menstrual", "Prepara lo que necesitas", "🎒", onKit) }
        item { CardButton("Necesito ayuda", "Busca apoyo de una persona adulta de confianza", "🤝", onHelp) }
        item { CardButton("Privacidad", "Información sobre tus datos", "🔒", onPrivacy) }
        item {
            Card(Modifier.fillMaxWidth().padding(22.dp), RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Mint)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Versión 5.1", fontWeight = FontWeight.Bold, color = Purple)
                    Text("Mi Primer Ciclo")
                }
            }
        }
    }
}

@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Header("Privacidad", "Tu información merece cuidado", onBack)
        Text("Esta versión de prueba no incluye cuentas ni sincronización en línea. Evita ingresar información que te identifique. Antes de publicar, se debe verificar técnicamente cómo se guardan y protegen los registros.", fontSize = 16.sp, lineHeight = 24.sp)
    }
}
