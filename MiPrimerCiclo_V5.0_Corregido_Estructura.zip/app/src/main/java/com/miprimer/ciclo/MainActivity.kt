package com.miprimer.ciclo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Pink = Color(0xFFE98AB8)
private val Purple = Color(0xFF7254A5)
private val Mint = Color(0xFFB9E5D5)
private val Cream = Color(0xFFFFF7FB)

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContent { App() }
 }
}

@Composable fun App() {
 var tab by remember { mutableStateOf(0) }
 MaterialTheme { Surface(color= Cream) {
  Column(Modifier.fillMaxSize()) {
   Box(Modifier.weight(1f)) {
    when(tab) { 0 -> Home(); 1 -> Calendar(); 2 -> Learn(); else -> More() }
   }
   NavigationBar(containerColor=Color.White) {
    listOf("Inicio","Calendario","Aprender","Más").forEachIndexed { i,n ->
     NavigationBarItem(selected=tab==i,onClick={tab=i},
      icon={Text(listOf("⌂","◫","★","⋯")[i],fontSize=20.sp)},
      label={Text(n)})
    }
   }
  }
 }}
}

@Composable fun Header(title:String, subtitle:String?=null) {
 Column(Modifier.padding(22.dp,20.dp,22.dp,8.dp)) {
  Text(title,fontSize=28.sp,fontWeight=FontWeight.Bold,color=Purple)
  subtitle?.let { Text(it,fontSize=15.sp,color=Color.DarkGray) }
 }
}

@Composable fun CardButton(title:String, text:String, emoji:String, onClick:()->Unit={}) {
 Card(onClick = onClick,
  modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
  shape = RoundedCornerShape(22.dp),
  colors = CardDefaults.cardColors(containerColor = Color.White)) {
  Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
   Text(emoji,fontSize=28.sp); Spacer(Modifier.width(14.dp))
   Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold,color=Purple);Text(text,fontSize=13.sp)}
   Text("›",fontSize=28.sp,color=Pink)
  }
 }
}

@Composable fun Home() {
 LazyColumn(Modifier.fillMaxSize()) {
  item {
   Header("Mi Primer Ciclo","Tu cuerpo • Tu ritmo • Tu bienestar")
   Text("Aprende, conoce y entiende los cambios de tu cuerpo. 💜",
    Modifier.padding(horizontal=22.dp),fontSize=17.sp)
   Spacer(Modifier.height(10.dp))
  }
  item { CardButton("Mi calendario","Registra tus días de forma sencilla","📅") }
  item { CardButton("Aprendiendo sobre mi cuerpo","Información clara y apropiada para tu edad","📚") }
  item { CardButton("¿Cómo me siento hoy?","Registra emociones y síntomas","😊") }
  item { CardButton("Mi kit menstrual","Qué llevar contigo para sentirte preparada","🎒") }
  item { CardButton("Necesito ayuda","Hablar con un adulto de confianza es importante","💗") }
  item {
   Card(Modifier.fillMaxWidth().padding(22.dp),RoundedCornerShape(22.dp),
    colors=CardDefaults.cardColors(Color(0xFFF1EAF9))) {
    Column(Modifier.padding(18.dp)){Text("Tu privacidad es nuestra prioridad 🔒",fontWeight=FontWeight.Bold,color=Purple)
     Text("Tus datos se guardan localmente en el dispositivo.",Modifier.padding(top=6.dp),fontSize=13.sp)}
   }
  }
 }
}

@Composable fun Calendar() {
 LazyColumn(Modifier.fillMaxSize()) {
  item { Header("Mi calendario","Agosto 2026") }
  item {
   Card(Modifier.padding(16.dp).fillMaxWidth(),RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(Color.White)) {
    Column(Modifier.padding(18.dp)) {
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("‹",fontSize=28.sp);Text("Agosto 2026",fontWeight=FontWeight.Bold);Text("›",fontSize=28.sp)}
     Text("L   M   M   J   V   S   D",Modifier.padding(vertical=18.dp),fontWeight=FontWeight.Bold)
     val days=(1..31).toList()
     days.chunked(7).forEach { week -> Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){week.forEach{d->Box(Modifier.size(38.dp).background(if(d in 5..7) Color(0xFFF3A2C6) else Color.Transparent,RoundedCornerShape(50.dp)),contentAlignment=Alignment.Center){Text("$d")}}} }
     Spacer(Modifier.height(15.dp));Text("🔴 Menstruación   🟢 Fértil aprox.   🟣 Síntomas",fontSize=12.sp)
    }
   }
  }
  item { Text("Al principio es normal que tu ciclo cambie de un mes a otro. ¡Cada cuerpo es único! 💜",Modifier.padding(22.dp),color=Purple,fontWeight=FontWeight.Bold) }
 }
}

@Composable fun Learn() {
 LazyColumn(Modifier.fillMaxSize()) {
  item { Header("Aprendiendo sobre mi cuerpo","Información sencilla y sin vergüenza") }
  val topics=listOf(
   "¿Qué es la pubertad?" to "Descubre por qué tu cuerpo está cambiando. 🌸",
   "Cambios en mi cuerpo" to "Conoce los cambios físicos y emocionales. 💕",
   "Mi primera menstruación" to "Cada cuerpo tiene su propio ritmo. 🩷",
   "Higiene y cuidado" to "Consejos para sentirte limpia y cómoda. 🫧",
   "Mitos y verdades" to "Aprende qué es cierto y qué no. ⭐")
  topics.forEach { (a,b) -> item { CardButton(a,b,"🌷") } }
 }
}

@Composable fun More() {
 LazyColumn(Modifier.fillMaxSize()) {
  item { Header("Más","Herramientas y acompañamiento") }
  item { CardButton("Mi kit menstrual","Toallas, ropa interior extra, pañuelos y más","🎒") }
  item { CardButton("Necesito ayuda","Mamá, papá, familiar, profesora u orientadora","🤝") }
  item { CardButton("Privacidad","Tus registros permanecen en tu dispositivo","🔒") }
  item {
   Card(Modifier.padding(22.dp).fillMaxWidth(),RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(Mint)) {
    Column(Modifier.padding(18.dp)){Text("Versión 5.0",fontWeight=FontWeight.Bold,color=Purple);Text("Mi Primer Ciclo")}
   }
  }
 }
}
